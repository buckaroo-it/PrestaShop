<?php

class EmptyNewlineHeader extends Module
{
    // This PHP file has no header comment but does have an empty newline right after the <?php tag
    // Most editors/IDEs add this newline automatically
    // It should add the license header without adding an unnecessary extra empty newline 
    // This also keeps validator.prestashop.com happy :)
}
