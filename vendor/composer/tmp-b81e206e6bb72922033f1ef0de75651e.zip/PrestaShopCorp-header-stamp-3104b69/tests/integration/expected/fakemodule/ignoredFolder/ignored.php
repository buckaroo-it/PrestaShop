<?php

class ignored {

}
